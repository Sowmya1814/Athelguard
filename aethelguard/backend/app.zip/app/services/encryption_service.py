"""
AethelGuard Encryption Service - Enhanced Security
----------------------------------------------------
Security Architecture:

Level 1: Per-file AES-256-GCM key (unique per upload)
Level 2: Per-user derived key (from password + salt)
Level 3: Master AES key (fallback, from .env)

Flow:
  User uploads file/text
        ↓
  Generate unique per-file AES-256 key
        ↓
  Encrypt content with per-file key
        ↓
  Encrypt per-file key with USER'S derived key
        ↓
  User's derived key = PBKDF2(user_password + user_salt + master_key)
        ↓
  Store: encrypted_content + encrypted_file_key + iv + salt
        ↓
  Even if DB leaked → needs user password to decrypt!
"""

import os
import base64
import hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes


# ─────────────────────────────────────────────────────────────
# MASTER KEY (from .env — last line of defense)
# ─────────────────────────────────────────────────────────────
def _get_master_key() -> bytes:
    """Get master AES key from environment."""
    hex_key = os.getenv("MASTER_AES_KEY")
    if not hex_key:
        raise ValueError("MASTER_AES_KEY not set in .env")
    return bytes.fromhex(hex_key)


# ─────────────────────────────────────────────────────────────
# PER-USER KEY DERIVATION (PBKDF2)
# Even if DB is hacked → needs user's password to decrypt
# ─────────────────────────────────────────────────────────────
def derive_user_key(user_id: int, password_hash: str) -> bytes:
    """
    Derive a unique AES-256 key for each user.
    Uses: PBKDF2(password_hash + master_key + user_id)
    
    This means:
    - Different key for every user
    - Changes if user changes password
    - Requires BOTH password AND master key to derive
    - Hacker needs user's password even if they have the DB
    """
    master_key = _get_master_key()
    
    # Salt = master_key + user_id (unique per user, not stored in DB)
    salt = hashlib.sha256(
        master_key + str(user_id).encode("utf-8")
    ).digest()
    
    # Derive key using PBKDF2 with 200,000 iterations
    kdf = PBKDF2HMAC(
        algorithm  = hashes.SHA256(),
        length     = 32,        # 256-bit key
        salt       = salt,
        iterations = 200_000,   # 200k iterations = slow for brute force
    )
    
    # Use password_hash as the input (not plain password)
    return kdf.derive(password_hash.encode("utf-8"))


# ─────────────────────────────────────────────────────────────
# PER-FILE KEY GENERATION
# ─────────────────────────────────────────────────────────────
def generate_file_key() -> bytes:
    """Generate a fresh random AES-256 key for ONE file/text."""
    return os.urandom(32)  # 256 bits


# ─────────────────────────────────────────────────────────────
# ENCRYPT PER-FILE KEY (with user's derived key)
# ─────────────────────────────────────────────────────────────
def encrypt_file_key(per_file_key: bytes,
                     user_id: int = None,
                     password_hash: str = None) -> tuple:
    """
    Encrypt the per-file key.
    
    If user_id + password_hash provided → use user-derived key (MORE SECURE)
    Otherwise → fall back to master key
    
    Returns: (encrypted_key_b64, iv_b64)
    """
    if user_id and password_hash:
        encryption_key = derive_user_key(user_id, password_hash)
    else:
        encryption_key = _get_master_key()

    iv    = os.urandom(12)
    aesgcm = AESGCM(encryption_key)
    encrypted_key = aesgcm.encrypt(iv, per_file_key, None)

    return (
        base64.b64encode(encrypted_key).decode("utf-8"),
        base64.b64encode(iv).decode("utf-8")
    )


def decrypt_file_key(encrypted_key_b64: str, iv_b64: str,
                     user_id: int = None,
                     password_hash: str = None) -> bytes:
    """
    Decrypt the per-file key.
    Must use same method (user-derived or master) as encryption.
    """
    if user_id and password_hash:
        encryption_key = derive_user_key(user_id, password_hash)
    else:
        encryption_key = _get_master_key()

    iv            = base64.b64decode(iv_b64)
    encrypted_key = base64.b64decode(encrypted_key_b64)
    aesgcm        = AESGCM(encryption_key)
    return aesgcm.decrypt(iv, encrypted_key, None)


# ─────────────────────────────────────────────────────────────
# ENCRYPT TEXT
# ─────────────────────────────────────────────────────────────
def encrypt_text(plain_text: str,
                 user_id: int = None,
                 password_hash: str = None) -> dict:
    """
    Encrypt a text string with AES-256-GCM.
    Returns dict with all data needed to decrypt later.
    """
    per_file_key = generate_file_key()

    # Encrypt the actual text
    text_iv = os.urandom(12)
    aesgcm  = AESGCM(per_file_key)
    encrypted_bytes = aesgcm.encrypt(text_iv, plain_text.encode("utf-8"), None)

    # Encrypt the per-file key
    enc_key_b64, key_iv_b64 = encrypt_file_key(
        per_file_key, user_id, password_hash
    )

    return {
        "encrypted_content":  base64.b64encode(encrypted_bytes).decode("utf-8"),
        "encrypted_file_key": enc_key_b64,
        "iv":                 base64.b64encode(text_iv).decode("utf-8"),
        "key_iv":             key_iv_b64,
    }


def decrypt_text(encrypted_content_b64: str,
                 encrypted_file_key_b64: str,
                 iv_b64: str,
                 key_iv_b64: str,
                 user_id: int = None,
                 password_hash: str = None) -> str:
    """Decrypt a text item. Returns original plain text."""
    per_file_key = decrypt_file_key(
        encrypted_file_key_b64, key_iv_b64, user_id, password_hash
    )
    iv              = base64.b64decode(iv_b64)
    encrypted_bytes = base64.b64decode(encrypted_content_b64)
    aesgcm          = AESGCM(per_file_key)
    return aesgcm.decrypt(iv, encrypted_bytes, None).decode("utf-8")


# ─────────────────────────────────────────────────────────────
# ENCRYPT FILE BYTES
# ─────────────────────────────────────────────────────────────
def encrypt_file_bytes(file_bytes: bytes,
                       user_id: int = None,
                       password_hash: str = None) -> dict:
    """
    Encrypt raw file bytes with AES-256-GCM.
    Returns dict with encrypted data and keys.
    """
    per_file_key = generate_file_key()

    file_iv = os.urandom(12)
    aesgcm  = AESGCM(per_file_key)
    encrypted_bytes = aesgcm.encrypt(file_iv, file_bytes, None)

    enc_key_b64, key_iv_b64 = encrypt_file_key(
        per_file_key, user_id, password_hash
    )

    return {
        "encrypted_bytes":    encrypted_bytes,
        "encrypted_file_key": enc_key_b64,
        "iv":                 base64.b64encode(file_iv).decode("utf-8"),
        "key_iv":             key_iv_b64,
    }


def decrypt_file_bytes(encrypted_bytes: bytes,
                       encrypted_file_key_b64: str,
                       iv_b64: str,
                       key_iv_b64: str,
                       user_id: int = None,
                       password_hash: str = None) -> bytes:
    """Decrypt raw file bytes. Returns original file bytes."""
    per_file_key = decrypt_file_key(
        encrypted_file_key_b64, key_iv_b64, user_id, password_hash
    )
    iv     = base64.b64decode(iv_b64)
    aesgcm = AESGCM(per_file_key)
    return aesgcm.decrypt(iv, encrypted_bytes, None)
